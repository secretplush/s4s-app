'use client';

import { useState, useEffect } from 'react';

// Mock model data - will be replaced with real API data
const mockModelData = {
  name: 'Sophia',
  username: 'sophiarose',
  avatar: null,
  earnings: {
    today: 847.32,
    week: 4892.45,
    month: 18934.67,
    allTime: 127834.89,
  },
  stats: {
    fans: 2847,
    messages: 156,
    pendingCustoms: 3,
    contentUploaded: 78,
  },
  contentProgress: {
    selfies: { uploaded: 25, required: 20 },
    fullBody: { uploaded: 18, required: 15 },
    videos: { uploaded: 12, required: 10 },
    nudes: { uploaded: 23, required: 20 },
  },
  upcomingStreams: [
    { date: '2026-02-06', time: '8:00 PM', platform: 'Chaturbate', duration: '4 hours' },
    { date: '2026-02-08', time: '9:00 PM', platform: 'Chaturbate', duration: '4 hours' },
  ],
  pendingCustoms: [
    { id: 1, fan: 'BigSpender42', request: '5 min custom video - shower scene', price: 150, status: 'pending' },
    { id: 2, fan: 'LoyalFan99', request: '10 photos - lingerie set', price: 75, status: 'pending' },
    { id: 3, fan: 'VIPMember', request: 'Voice message - 2 mins', price: 50, status: 'approved' },
  ],
  recentActivity: [
    { type: 'earning', amount: 20, source: 'PPV Message', time: '5 mins ago' },
    { type: 'earning', amount: 15, source: 'Tip', time: '12 mins ago' },
    { type: 'earning', amount: 50, source: 'Custom Request', time: '1 hour ago' },
    { type: 'fan', count: 3, time: '2 hours ago' },
    { type: 'earning', amount: 20, source: 'PPV Message', time: '3 hours ago' },
  ],
};

export default function Dashboard() {
  const [model, setModel] = useState(mockModelData);
  const [activeTab, setActiveTab] = useState<'overview' | 'content' | 'customs' | 'schedule'>('overview');
  const [liveEarnings, setLiveEarnings] = useState(model.earnings.today);

  // Simulate live earnings updates
  useEffect(() => {
    const interval = setInterval(() => {
      const increment = Math.random() * 15 + 5;
      setLiveEarnings(prev => prev + increment);
    }, 8000 + Math.random() * 12000);
    return () => clearInterval(interval);
  }, []);

  const contentTypes = [
    { key: 'selfies', label: 'Selfies', icon: '📸', color: 'pink' },
    { key: 'fullBody', label: 'Full Body', icon: '🪞', color: 'purple' },
    { key: 'videos', label: 'Videos', icon: '🎬', color: 'blue' },
    { key: 'nudes', label: 'Explicit', icon: '🔥', color: 'red' },
  ];

  return (
    <main className="min-h-screen bg-plush-dark">
      {/* Top Navigation */}
      <nav className="bg-plush-darker border-b border-plush-border px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <span className="text-2xl font-bold tracking-wider text-plush-text">PLUSH</span>
            <span className="text-plush-text-muted">|</span>
            <span className="text-plush-text-muted">Model Dashboard</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-plush-card border border-plush-border">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-plush-pink to-pink-600 flex items-center justify-center text-white font-bold text-sm">
                {model.name[0]}
              </div>
              <span className="text-plush-text font-medium">{model.name}</span>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome & Quick Stats */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-plush-text mb-2">
            Welcome back, {model.name} 👋
          </h1>
          <p className="text-plush-text-muted">Here's how you're doing today</p>
        </div>

        {/* Earnings Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="card-premium rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-plush-text-muted text-sm">Today's Earnings</span>
              <span className="text-xs px-2 py-1 bg-green-500/20 text-green-400 rounded-full animate-pulse">LIVE</span>
            </div>
            <div className="text-3xl font-bold text-plush-text">
              ${liveEarnings.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-sm text-green-400 mt-2">+12.5% vs yesterday</div>
          </div>

          <div className="card-premium rounded-2xl p-6">
            <div className="text-plush-text-muted text-sm mb-4">This Week</div>
            <div className="text-3xl font-bold text-plush-text">
              ${model.earnings.week.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-sm text-green-400 mt-2">+8.2% vs last week</div>
          </div>

          <div className="card-premium rounded-2xl p-6">
            <div className="text-plush-text-muted text-sm mb-4">This Month</div>
            <div className="text-3xl font-bold text-plush-text">
              ${model.earnings.month.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-sm text-green-400 mt-2">+15.7% vs last month</div>
          </div>

          <div className="card-premium rounded-2xl p-6">
            <div className="text-plush-text-muted text-sm mb-4">All Time</div>
            <div className="text-3xl font-bold text-gradient">
              ${model.earnings.allTime.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-sm text-plush-text-muted mt-2">Since joining Plush</div>
          </div>
        </div>

        {/* Main Content Tabs */}
        <div className="flex gap-2 mb-6 border-b border-plush-border pb-4">
          {[
            { id: 'overview', label: 'Overview', icon: '📊' },
            { id: 'content', label: 'Content', icon: '📁' },
            { id: 'customs', label: 'Custom Requests', icon: '💬' },
            { id: 'schedule', label: 'Schedule', icon: '📅' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-plush-pink text-white'
                  : 'text-plush-text-muted hover:text-plush-text hover:bg-plush-card'
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-6">
            {activeTab === 'overview' && (
              <>
                {/* Quick Stats */}
                <div className="card-premium rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-plush-text mb-4">Quick Stats</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 rounded-xl bg-plush-darker">
                      <div className="text-2xl font-bold text-plush-pink">{model.stats.fans.toLocaleString()}</div>
                      <div className="text-sm text-plush-text-muted">Total Fans</div>
                    </div>
                    <div className="text-center p-4 rounded-xl bg-plush-darker">
                      <div className="text-2xl font-bold text-plush-pink">{model.stats.messages}</div>
                      <div className="text-sm text-plush-text-muted">Unread DMs</div>
                    </div>
                    <div className="text-center p-4 rounded-xl bg-plush-darker">
                      <div className="text-2xl font-bold text-yellow-400">{model.stats.pendingCustoms}</div>
                      <div className="text-sm text-plush-text-muted">Pending Customs</div>
                    </div>
                    <div className="text-center p-4 rounded-xl bg-plush-darker">
                      <div className="text-2xl font-bold text-green-400">{model.stats.contentUploaded}</div>
                      <div className="text-sm text-plush-text-muted">Content Uploaded</div>
                    </div>
                  </div>
                </div>

                {/* Content Progress */}
                <div className="card-premium rounded-2xl p-6">
                  <h3 className="text-lg font-bold text-plush-text mb-4">Content Progress</h3>
                  <div className="space-y-4">
                    {contentTypes.map(type => {
                      const progress = model.contentProgress[type.key as keyof typeof model.contentProgress];
                      const percentage = Math.min((progress.uploaded / progress.required) * 100, 100);
                      const isComplete = progress.uploaded >= progress.required;
                      return (
                        <div key={type.key}>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-plush-text">
                              {type.icon} {type.label}
                            </span>
                            <span className={`text-sm ${isComplete ? 'text-green-400' : 'text-plush-text-muted'}`}>
                              {progress.uploaded}/{progress.required} {isComplete && '✓'}
                            </span>
                          </div>
                          <div className="h-2 bg-plush-darker rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all duration-500 ${
                                isComplete ? 'bg-green-500' : 'bg-plush-pink'
                              }`}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            )}

            {activeTab === 'content' && (
              <div className="card-premium rounded-2xl p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-bold text-plush-text">Upload Content</h3>
                  <button className="btn-glow px-4 py-2 rounded-lg text-white font-medium text-sm">
                    + Upload New
                  </button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {contentTypes.map(type => (
                    <div
                      key={type.key}
                      className="aspect-square rounded-xl bg-plush-darker border-2 border-dashed border-plush-border hover:border-plush-pink transition-colors cursor-pointer flex flex-col items-center justify-center gap-2"
                    >
                      <span className="text-3xl">{type.icon}</span>
                      <span className="text-sm text-plush-text-muted">{type.label}</span>
                    </div>
                  ))}
                </div>
                <p className="text-sm text-plush-text-muted mt-4 text-center">
                  Drag and drop files or click to upload
                </p>
              </div>
            )}

            {activeTab === 'customs' && (
              <div className="card-premium rounded-2xl p-6">
                <h3 className="text-lg font-bold text-plush-text mb-4">Pending Custom Requests</h3>
                <div className="space-y-4">
                  {model.pendingCustoms.map(custom => (
                    <div key={custom.id} className="p-4 rounded-xl bg-plush-darker border border-plush-border">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <span className="text-plush-text font-medium">{custom.fan}</span>
                          <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${
                            custom.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'
                          }`}>
                            {custom.status}
                          </span>
                        </div>
                        <span className="text-plush-pink font-bold">${custom.price}</span>
                      </div>
                      <p className="text-sm text-plush-text-muted mb-3">{custom.request}</p>
                      {custom.status === 'pending' && (
                        <div className="flex gap-2">
                          <button className="flex-1 py-2 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 transition-colors text-sm font-medium">
                            Accept
                          </button>
                          <button className="flex-1 py-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors text-sm font-medium">
                            Decline
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'schedule' && (
              <div className="card-premium rounded-2xl p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-bold text-plush-text">Upcoming Streams</h3>
                  <button className="btn-glow px-4 py-2 rounded-lg text-white font-medium text-sm">
                    + Add Stream
                  </button>
                </div>
                <div className="space-y-4">
                  {model.upcomingStreams.map((stream, i) => (
                    <div key={i} className="p-4 rounded-xl bg-plush-darker border border-plush-border flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-plush-pink/20 flex items-center justify-center text-2xl">
                          📹
                        </div>
                        <div>
                          <div className="text-plush-text font-medium">{stream.platform}</div>
                          <div className="text-sm text-plush-text-muted">
                            {stream.date} at {stream.time} • {stream.duration}
                          </div>
                        </div>
                      </div>
                      <button className="px-3 py-1 rounded-lg border border-plush-border text-plush-text-muted hover:text-plush-text hover:border-plush-pink transition-colors text-sm">
                        Edit
                      </button>
                    </div>
                  ))}
                </div>
                <div className="mt-6 p-4 rounded-xl bg-plush-pink/10 border border-plush-pink/30">
                  <div className="flex items-center gap-2 text-plush-pink font-medium mb-1">
                    💡 Streaming Tip
                  </div>
                  <p className="text-sm text-plush-text-muted">
                    Stream 4 hours/day, 5 days/week for the first 30 days to maximize Chaturbate's new streamer promotion!
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recent Activity */}
            <div className="card-premium rounded-2xl p-6">
              <h3 className="text-lg font-bold text-plush-text mb-4">Recent Activity</h3>
              <div className="space-y-3">
                {model.recentActivity.map((activity, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-plush-darker">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                      activity.type === 'earning' ? 'bg-green-500/20 text-green-400' : 'bg-plush-pink/20 text-plush-pink'
                    }`}>
                      {activity.type === 'earning' ? '$' : '👤'}
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-plush-text">
                        {activity.type === 'earning' 
                          ? `+$${activity.amount} from ${activity.source}`
                          : `+${activity.count} new fans`
                        }
                      </div>
                      <div className="text-xs text-plush-text-muted">{activity.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="card-premium rounded-2xl p-6">
              <h3 className="text-lg font-bold text-plush-text mb-4">Quick Actions</h3>
              <div className="space-y-2">
                <button className="w-full py-3 px-4 rounded-xl bg-plush-darker hover:bg-plush-card border border-plush-border text-left text-plush-text transition-colors flex items-center gap-3">
                  <span className="text-xl">📤</span>
                  <span>Upload Content</span>
                </button>
                <button className="w-full py-3 px-4 rounded-xl bg-plush-darker hover:bg-plush-card border border-plush-border text-left text-plush-text transition-colors flex items-center gap-3">
                  <span className="text-xl">📅</span>
                  <span>Schedule Stream</span>
                </button>
                <button className="w-full py-3 px-4 rounded-xl bg-plush-darker hover:bg-plush-card border border-plush-border text-left text-plush-text transition-colors flex items-center gap-3">
                  <span className="text-xl">💬</span>
                  <span>Contact Manager</span>
                </button>
                <button className="w-full py-3 px-4 rounded-xl bg-plush-darker hover:bg-plush-card border border-plush-border text-left text-plush-text transition-colors flex items-center gap-3">
                  <span className="text-xl">📊</span>
                  <span>View Analytics</span>
                </button>
              </div>
            </div>

            {/* Support Card */}
            <div className="card-premium rounded-2xl p-6 bg-gradient-to-br from-plush-pink/20 to-transparent border-plush-pink/30">
              <h3 className="text-lg font-bold text-plush-text mb-2">Need Help?</h3>
              <p className="text-sm text-plush-text-muted mb-4">
                Your dedicated manager is here for you 24/7.
              </p>
              <button className="w-full btn-glow py-3 rounded-xl text-white font-medium">
                Chat with Manager
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

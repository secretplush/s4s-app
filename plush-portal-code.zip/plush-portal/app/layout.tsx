import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PLUSH | Turn Your Content Into A 6-Figure Career",
  description: "Professional management for creators who want to stay anonymous, build passive income, and live the lifestyle they deserve. Join 120+ successful creators.",
  keywords: "OnlyFans management, content creator agency, influencer management, Plush, anonymous creator",
  openGraph: {
    title: "PLUSH | Turn Your Content Into A 6-Figure Career",
    description: "Professional management for creators who want to stay anonymous, build passive income, and live the lifestyle they deserve.",
    type: "website",
    images: [{ url: "/og-image.jpg", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "PLUSH | Turn Your Content Into A 6-Figure Career",
    description: "Professional management for creators. Anonymous. Passive income. Luxury lifestyle.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet" />
        <meta name="theme-color" content="#0A0A0B" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}

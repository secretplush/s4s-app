'use client';

import { useState } from 'react';

type Step = 'welcome' | 'contract' | 'profile' | 'content' | 'verification' | 'complete';

interface FormData {
  // Personal
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  country: string;
  state: string;
  
  // Social
  instagram: string;
  twitter: string;
  tiktok: string;
  existingOF: string;
  
  // Experience
  hasCreatorExperience: boolean;
  platforms: string[];
  monthlyGoal: string;
  referredBy: string;
  
  // Content
  contentComfort: string[];
  streamingInterest: boolean;
  availableHours: string;
  
  // Legal
  contractSigned: boolean;
  termsAccepted: boolean;
  over18Confirmed: boolean;
}

const initialFormData: FormData = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  dateOfBirth: '',
  country: '',
  state: '',
  instagram: '',
  twitter: '',
  tiktok: '',
  existingOF: '',
  hasCreatorExperience: false,
  platforms: [],
  monthlyGoal: '',
  referredBy: '',
  contentComfort: [],
  streamingInterest: false,
  availableHours: '',
  contractSigned: false,
  termsAccepted: false,
  over18Confirmed: false,
};

const steps: { id: Step; label: string; icon: string }[] = [
  { id: 'welcome', label: 'Welcome', icon: '👋' },
  { id: 'contract', label: 'Agreement', icon: '📝' },
  { id: 'profile', label: 'Profile', icon: '👤' },
  { id: 'content', label: 'Content', icon: '📸' },
  { id: 'verification', label: 'Verify', icon: '✓' },
  { id: 'complete', label: 'Done', icon: '🎉' },
];

const testimonials = [
  { name: 'Madison', earnings: '$47,000/mo', quote: 'Plush changed my life. I work from anywhere now.' },
  { name: 'Ashley', earnings: '$82,000/mo', quote: 'Best decision I ever made. The team handles everything.' },
  { name: 'Emma', earnings: '$156,000/mo', quote: 'I wish I started sooner. True passive income.' },
  { name: 'Olivia', earnings: '$63,000/mo', quote: 'Complete anonymity. My friends have no idea.' },
];

const contentOptions = [
  { id: 'selfies', label: 'Selfies & Photos', icon: '📸' },
  { id: 'lingerie', label: 'Lingerie Content', icon: '👙' },
  { id: 'implied', label: 'Implied Nude', icon: '🌸' },
  { id: 'topless', label: 'Topless', icon: '💫' },
  { id: 'full', label: 'Full Nude', icon: '🔥' },
  { id: 'explicit', label: 'Explicit/XXX', icon: '💋' },
];

const goalOptions = [
  { value: '5k', label: '$5,000/month', desc: 'Part-time income' },
  { value: '10k', label: '$10,000/month', desc: 'Replace a job' },
  { value: '25k', label: '$25,000/month', desc: 'Serious income' },
  { value: '50k', label: '$50,000+/month', desc: 'Life changing' },
];

export default function Onboarding() {
  const [currentStep, setCurrentStep] = useState<Step>('welcome');
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  const currentStepIndex = steps.findIndex(s => s.id === currentStep);
  const progress = ((currentStepIndex + 1) / steps.length) * 100;

  const nextStep = () => {
    const nextIndex = currentStepIndex + 1;
    if (nextIndex < steps.length) {
      setCurrentStep(steps[nextIndex].id);
    }
  };

  const prevStep = () => {
    const prevIndex = currentStepIndex - 1;
    if (prevIndex >= 0) {
      setCurrentStep(steps[prevIndex].id);
    }
  };

  const updateForm = (field: keyof FormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleContentComfort = (id: string) => {
    setFormData(prev => ({
      ...prev,
      contentComfort: prev.contentComfort.includes(id)
        ? prev.contentComfort.filter(c => c !== id)
        : [...prev.contentComfort, id]
    }));
  };

  return (
    <main className="min-h-screen bg-plush-dark">
      {/* Progress Bar */}
      <div className="fixed top-0 left-0 right-0 h-1 bg-plush-darker z-50">
        <div 
          className="h-full bg-gradient-to-r from-plush-pink to-pink-400 transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Header */}
      <header className="border-b border-plush-border bg-plush-darker/80 backdrop-blur-lg sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-6 py-4 flex justify-between items-center">
          <span className="text-2xl font-bold tracking-wider text-plush-text">PLUSH</span>
          <div className="flex items-center gap-2 text-sm text-plush-text-muted">
            Step {currentStepIndex + 1} of {steps.length}
          </div>
        </div>
      </header>

      {/* Step Indicators */}
      <div className="max-w-4xl mx-auto px-6 py-6">
        <div className="flex justify-between">
          {steps.map((step, i) => (
            <div key={step.id} className="flex flex-col items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg transition-all ${
                i < currentStepIndex 
                  ? 'bg-green-500 text-white'
                  : i === currentStepIndex
                  ? 'bg-plush-pink text-white scale-110'
                  : 'bg-plush-card text-plush-text-muted border border-plush-border'
              }`}>
                {i < currentStepIndex ? '✓' : step.icon}
              </div>
              <span className={`text-xs mt-2 hidden md:block ${
                i === currentStepIndex ? 'text-plush-text' : 'text-plush-text-muted'
              }`}>
                {step.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 pb-24">
        {/* Welcome Step */}
        {currentStep === 'welcome' && (
          <div className="text-center py-12 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold text-plush-text mb-6">
              Welcome to <span className="text-gradient">Plush</span>
            </h1>
            <p className="text-xl text-plush-text-muted mb-12 max-w-2xl mx-auto">
              You're about to join 120+ creators earning $10K-$200K per month. 
              Let's get you set up in just a few minutes.
            </p>

            {/* Testimonial Carousel */}
            <div className="card-premium rounded-2xl p-8 mb-12 max-w-xl mx-auto">
              <div className="text-5xl mb-4">"</div>
              <p className="text-xl text-plush-text italic mb-6">
                {testimonials[testimonialIndex].quote}
              </p>
              <div className="flex items-center justify-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-plush-pink to-pink-600" />
                <div className="text-left">
                  <div className="text-plush-text font-medium">{testimonials[testimonialIndex].name}</div>
                  <div className="text-plush-pink font-bold">{testimonials[testimonialIndex].earnings}</div>
                </div>
              </div>
              <div className="flex justify-center gap-2 mt-6">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setTestimonialIndex(i)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      i === testimonialIndex ? 'bg-plush-pink w-6' : 'bg-plush-border'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* What You'll Get */}
            <div className="grid md:grid-cols-3 gap-4 mb-12">
              {[
                { icon: '🔒', title: 'Complete Anonymity', desc: 'Your identity stays hidden' },
                { icon: '💰', title: 'Passive Income', desc: 'We handle the work' },
                { icon: '👯‍♀️', title: 'Community', desc: 'Join amazing women' },
              ].map(item => (
                <div key={item.title} className="card-premium rounded-xl p-6">
                  <div className="text-3xl mb-3">{item.icon}</div>
                  <div className="text-plush-text font-medium mb-1">{item.title}</div>
                  <div className="text-sm text-plush-text-muted">{item.desc}</div>
                </div>
              ))}
            </div>

            <button onClick={nextStep} className="btn-glow px-12 py-4 rounded-full text-white font-bold text-lg">
              Let's Get Started →
            </button>
          </div>
        )}

        {/* Contract Step */}
        {currentStep === 'contract' && (
          <div className="py-8 animate-fade-in">
            <h2 className="text-3xl font-bold text-plush-text mb-4 text-center">
              Creator Agreement
            </h2>
            <p className="text-plush-text-muted text-center mb-8">
              Please review and accept our terms to continue
            </p>

            <div className="card-premium rounded-2xl p-6 mb-8 max-h-96 overflow-y-auto">
              <h3 className="text-lg font-bold text-plush-text mb-4">Plush Creator Agreement</h3>
              <div className="text-sm text-plush-text-muted space-y-4">
                <p>This Creator Agreement ("Agreement") is entered into between Plush ("Company") and you ("Creator").</p>
                
                <h4 className="text-plush-text font-medium mt-4">1. Services</h4>
                <p>Plush will provide management services including account management, fan engagement, content strategy, and promotional support for your OnlyFans account.</p>
                
                <h4 className="text-plush-text font-medium mt-4">2. Revenue Split</h4>
                <p>Creator shall receive 50% of all net revenue generated through the managed OnlyFans account. Payments are processed via Daisio split pay and distributed weekly.</p>
                
                <h4 className="text-plush-text font-medium mt-4">3. Content Ownership</h4>
                <p>Creator retains full ownership of all content. Plush is granted a license to post and promote content on the managed account.</p>
                
                <h4 className="text-plush-text font-medium mt-4">4. Term & Termination</h4>
                <p>This agreement has an initial term of 6 months and may be terminated by either party with 30 days written notice.</p>
                
                <h4 className="text-plush-text font-medium mt-4">5. Confidentiality</h4>
                <p>Both parties agree to maintain confidentiality of all business information and creator identity.</p>
              </div>
            </div>

            <div className="space-y-4 mb-8">
              <label className="flex items-start gap-3 p-4 rounded-xl bg-plush-card border border-plush-border cursor-pointer hover:border-plush-pink transition-colors">
                <input
                  type="checkbox"
                  checked={formData.over18Confirmed}
                  onChange={e => updateForm('over18Confirmed', e.target.checked)}
                  className="mt-1 w-5 h-5 rounded border-plush-border bg-plush-darker accent-plush-pink"
                />
                <div>
                  <span className="text-plush-text font-medium">I confirm I am 18 years or older</span>
                  <p className="text-sm text-plush-text-muted">Required for OnlyFans verification</p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl bg-plush-card border border-plush-border cursor-pointer hover:border-plush-pink transition-colors">
                <input
                  type="checkbox"
                  checked={formData.termsAccepted}
                  onChange={e => updateForm('termsAccepted', e.target.checked)}
                  className="mt-1 w-5 h-5 rounded border-plush-border bg-plush-darker accent-plush-pink"
                />
                <div>
                  <span className="text-plush-text font-medium">I accept the Creator Agreement</span>
                  <p className="text-sm text-plush-text-muted">You can review this anytime in your dashboard</p>
                </div>
              </label>

              <label className="flex items-start gap-3 p-4 rounded-xl bg-plush-card border border-plush-border cursor-pointer hover:border-plush-pink transition-colors">
                <input
                  type="checkbox"
                  checked={formData.contractSigned}
                  onChange={e => updateForm('contractSigned', e.target.checked)}
                  className="mt-1 w-5 h-5 rounded border-plush-border bg-plush-darker accent-plush-pink"
                />
                <div>
                  <span className="text-plush-text font-medium">I agree to the 50/50 revenue split</span>
                  <p className="text-sm text-plush-text-muted">Paid weekly via Daisio split pay</p>
                </div>
              </label>
            </div>

            <div className="flex gap-4">
              <button onClick={prevStep} className="px-8 py-4 rounded-full border border-plush-border text-plush-text font-medium hover:border-plush-pink transition-colors">
                ← Back
              </button>
              <button 
                onClick={nextStep}
                disabled={!formData.over18Confirmed || !formData.termsAccepted || !formData.contractSigned}
                className="flex-1 btn-glow px-8 py-4 rounded-full text-white font-bold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Accept & Continue →
              </button>
            </div>
          </div>
        )}

        {/* Profile Step */}
        {currentStep === 'profile' && (
          <div className="py-8 animate-fade-in">
            <h2 className="text-3xl font-bold text-plush-text mb-4 text-center">
              Tell Us About Yourself
            </h2>
            <p className="text-plush-text-muted text-center mb-8">
              This information is kept 100% confidential
            </p>

            <div className="space-y-6">
              {/* Basic Info */}
              <div className="card-premium rounded-2xl p-6">
                <h3 className="text-lg font-medium text-plush-text mb-4">Basic Information</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-plush-text-muted mb-2">First Name</label>
                    <input
                      type="text"
                      value={formData.firstName}
                      onChange={e => updateForm('firstName', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
                      placeholder="Your first name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-plush-text-muted mb-2">Last Name</label>
                    <input
                      type="text"
                      value={formData.lastName}
                      onChange={e => updateForm('lastName', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
                      placeholder="Your last name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-plush-text-muted mb-2">Email</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={e => updateForm('email', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-plush-text-muted mb-2">Phone</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={e => updateForm('phone', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-plush-text-muted mb-2">Date of Birth</label>
                    <input
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={e => updateForm('dateOfBirth', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-plush-text-muted mb-2">Country</label>
                    <select
                      value={formData.country}
                      onChange={e => updateForm('country', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
                    >
                      <option value="">Select country</option>
                      <option value="US">United States</option>
                      <option value="CA">Canada</option>
                      <option value="UK">United Kingdom</option>
                      <option value="AU">Australia</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Social Media */}
              <div className="card-premium rounded-2xl p-6">
                <h3 className="text-lg font-medium text-plush-text mb-2">Social Media</h3>
                <p className="text-sm text-plush-text-muted mb-4">Optional - helps us grow your audience faster</p>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-plush-text-muted mb-2">Instagram</label>
                    <input
                      type="text"
                      value={formData.instagram}
                      onChange={e => updateForm('instagram', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
                      placeholder="@username"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-plush-text-muted mb-2">TikTok</label>
                    <input
                      type="text"
                      value={formData.tiktok}
                      onChange={e => updateForm('tiktok', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
                      placeholder="@username"
                    />
                  </div>
                </div>
              </div>

              {/* Goals */}
              <div className="card-premium rounded-2xl p-6">
                <h3 className="text-lg font-medium text-plush-text mb-4">What's Your Goal?</h3>
                <div className="grid md:grid-cols-2 gap-3">
                  {goalOptions.map(option => (
                    <label
                      key={option.value}
                      className={`p-4 rounded-xl border cursor-pointer transition-all ${
                        formData.monthlyGoal === option.value
                          ? 'border-plush-pink bg-plush-pink/10'
                          : 'border-plush-border bg-plush-darker hover:border-plush-pink/50'
                      }`}
                    >
                      <input
                        type="radio"
                        name="goal"
                        value={option.value}
                        checked={formData.monthlyGoal === option.value}
                        onChange={e => updateForm('monthlyGoal', e.target.value)}
                        className="hidden"
                      />
                      <div className="text-plush-text font-medium">{option.label}</div>
                      <div className="text-sm text-plush-text-muted">{option.desc}</div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Referral */}
              <div className="card-premium rounded-2xl p-6">
                <h3 className="text-lg font-medium text-plush-text mb-2">Referral Code</h3>
                <p className="text-sm text-plush-text-muted mb-4">Were you referred by someone?</p>
                <input
                  type="text"
                  value={formData.referredBy}
                  onChange={e => updateForm('referredBy', e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
                  placeholder="Enter referral code (optional)"
                />
              </div>
            </div>

            <div className="flex gap-4 mt-8">
              <button onClick={prevStep} className="px-8 py-4 rounded-full border border-plush-border text-plush-text font-medium hover:border-plush-pink transition-colors">
                ← Back
              </button>
              <button 
                onClick={nextStep}
                disabled={!formData.firstName || !formData.email}
                className="flex-1 btn-glow px-8 py-4 rounded-full text-white font-bold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Continue →
              </button>
            </div>
          </div>
        )}

        {/* Content Preferences Step */}
        {currentStep === 'content' && (
          <div className="py-8 animate-fade-in">
            <h2 className="text-3xl font-bold text-plush-text mb-4 text-center">
              Content Preferences
            </h2>
            <p className="text-plush-text-muted text-center mb-8">
              What types of content are you comfortable creating?
            </p>

            <div className="card-premium rounded-2xl p-6 mb-6">
              <h3 className="text-lg font-medium text-plush-text mb-4">Select all that apply</h3>
              <div className="grid md:grid-cols-3 gap-3">
                {contentOptions.map(option => (
                  <label
                    key={option.id}
                    className={`p-4 rounded-xl border cursor-pointer transition-all text-center ${
                      formData.contentComfort.includes(option.id)
                        ? 'border-plush-pink bg-plush-pink/10'
                        : 'border-plush-border bg-plush-darker hover:border-plush-pink/50'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={formData.contentComfort.includes(option.id)}
                      onChange={() => toggleContentComfort(option.id)}
                      className="hidden"
                    />
                    <div className="text-2xl mb-2">{option.icon}</div>
                    <div className="text-plush-text font-medium">{option.label}</div>
                  </label>
                ))}
              </div>
              <p className="text-sm text-plush-text-muted mt-4 text-center">
                💡 Tip: Creators who offer more content types typically earn 3-5x more
              </p>
            </div>

            <div className="card-premium rounded-2xl p-6 mb-6">
              <h3 className="text-lg font-medium text-plush-text mb-4">Interested in Live Streaming?</h3>
              <p className="text-sm text-plush-text-muted mb-4">
                Streaming on Chaturbate can significantly boost your earnings and fan base
              </p>
              <div className="flex gap-4">
                <label className={`flex-1 p-4 rounded-xl border cursor-pointer transition-all text-center ${
                  formData.streamingInterest ? 'border-plush-pink bg-plush-pink/10' : 'border-plush-border bg-plush-darker'
                }`}>
                  <input
                    type="radio"
                    name="streaming"
                    checked={formData.streamingInterest}
                    onChange={() => updateForm('streamingInterest', true)}
                    className="hidden"
                  />
                  <div className="text-2xl mb-2">📹</div>
                  <div className="text-plush-text font-medium">Yes, I'm interested!</div>
                </label>
                <label className={`flex-1 p-4 rounded-xl border cursor-pointer transition-all text-center ${
                  !formData.streamingInterest ? 'border-plush-pink bg-plush-pink/10' : 'border-plush-border bg-plush-darker'
                }`}>
                  <input
                    type="radio"
                    name="streaming"
                    checked={!formData.streamingInterest}
                    onChange={() => updateForm('streamingInterest', false)}
                    className="hidden"
                  />
                  <div className="text-2xl mb-2">❌</div>
                  <div className="text-plush-text font-medium">Not right now</div>
                </label>
              </div>
            </div>

            <div className="card-premium rounded-2xl p-6">
              <h3 className="text-lg font-medium text-plush-text mb-4">Weekly Availability</h3>
              <p className="text-sm text-plush-text-muted mb-4">
                How many hours per week can you dedicate to content creation?
              </p>
              <select
                value={formData.availableHours}
                onChange={e => updateForm('availableHours', e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-plush-darker border border-plush-border text-plush-text focus:border-plush-pink focus:outline-none transition-colors"
              >
                <option value="">Select availability</option>
                <option value="5">~5 hours/week</option>
                <option value="10">~10 hours/week</option>
                <option value="20">~20 hours/week</option>
                <option value="40">40+ hours/week (full time)</option>
              </select>
            </div>

            <div className="flex gap-4 mt-8">
              <button onClick={prevStep} className="px-8 py-4 rounded-full border border-plush-border text-plush-text font-medium hover:border-plush-pink transition-colors">
                ← Back
              </button>
              <button 
                onClick={nextStep}
                disabled={formData.contentComfort.length === 0}
                className="flex-1 btn-glow px-8 py-4 rounded-full text-white font-bold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Continue →
              </button>
            </div>
          </div>
        )}

        {/* Verification Step */}
        {currentStep === 'verification' && (
          <div className="py-8 animate-fade-in">
            <h2 className="text-3xl font-bold text-plush-text mb-4 text-center">
              Almost There!
            </h2>
            <p className="text-plush-text-muted text-center mb-8">
              We'll set up your accounts and guide you through verification
            </p>

            <div className="space-y-4 max-w-xl mx-auto">
              <div className="card-premium rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-plush-pink/20 flex items-center justify-center text-plush-pink font-bold">1</div>
                  <div>
                    <h3 className="text-plush-text font-medium mb-1">Check Your Email</h3>
                    <p className="text-sm text-plush-text-muted">
                      We'll send you login credentials for Google Chat and your OnlyFans dashboard access.
                    </p>
                  </div>
                </div>
              </div>

              <div className="card-premium rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-plush-pink/20 flex items-center justify-center text-plush-pink font-bold">2</div>
                  <div>
                    <h3 className="text-plush-text font-medium mb-1">Verify Your Identity</h3>
                    <p className="text-sm text-plush-text-muted">
                      OnlyFans requires ID verification. Take a clear photo of your ID on a black background. Takes 24-48 hours.
                    </p>
                  </div>
                </div>
              </div>

              <div className="card-premium rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-plush-pink/20 flex items-center justify-center text-plush-pink font-bold">3</div>
                  <div>
                    <h3 className="text-plush-text font-medium mb-1">Complete W9 Form</h3>
                    <p className="text-sm text-plush-text-muted">
                      Required for US creators. You'll do this through OnlyFans once verified.
                    </p>
                  </div>
                </div>
              </div>

              <div className="card-premium rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-plush-pink/20 flex items-center justify-center text-plush-pink font-bold">4</div>
                  <div>
                    <h3 className="text-plush-text font-medium mb-1">Upload Your First Content</h3>
                    <p className="text-sm text-plush-text-muted">
                      We'll guide you through uploading your initial content bundles to get your page launched.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-4 mt-8 max-w-xl mx-auto">
              <button onClick={prevStep} className="px-8 py-4 rounded-full border border-plush-border text-plush-text font-medium hover:border-plush-pink transition-colors">
                ← Back
              </button>
              <button 
                onClick={nextStep}
                className="flex-1 btn-glow px-8 py-4 rounded-full text-white font-bold"
              >
                Complete Setup →
              </button>
            </div>
          </div>
        )}

        {/* Complete Step */}
        {currentStep === 'complete' && (
          <div className="py-12 text-center animate-fade-in">
            <div className="text-6xl mb-6">🎉</div>
            <h2 className="text-4xl font-bold text-plush-text mb-4">
              You're All Set!
            </h2>
            <p className="text-xl text-plush-text-muted mb-8 max-w-xl mx-auto">
              Welcome to Plush, {formData.firstName || 'beautiful'}! Your journey to financial freedom starts now.
            </p>

            <div className="card-premium rounded-2xl p-8 max-w-xl mx-auto mb-8">
              <h3 className="text-lg font-bold text-plush-text mb-4">What Happens Next?</h3>
              <ul className="text-left space-y-3 text-plush-text-muted">
                <li className="flex items-center gap-3">
                  <span className="text-green-400">✓</span>
                  Your onboarding manager will reach out within 24 hours
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-green-400">✓</span>
                  Check your email for login credentials
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-green-400">✓</span>
                  Complete ID verification when prompted
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-green-400">✓</span>
                  Upload your first content batch
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-green-400">✓</span>
                  Go live and start earning!
                </li>
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="/dashboard" 
                className="btn-glow px-10 py-4 rounded-full text-white font-bold text-lg"
              >
                Go to Dashboard →
              </a>
              <a 
                href="/" 
                className="px-10 py-4 rounded-full border border-plush-border text-plush-text font-medium hover:border-plush-pink transition-colors"
              >
                Back to Home
              </a>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}

'use client';

import { useState, useEffect, useRef } from 'react';

// Anonymize username: "stephaniequinn" → "@st*********inn"
const anonymize = (name: string) => {
  const n = name.toLowerCase();
  const showStart = 2;
  const showEnd = 3;
  const starCount = Math.max(n.length - showStart - showEnd, 3);
  return `@${n.slice(0, showStart)}${'*'.repeat(starCount)}${n.slice(-showEnd)}`;
};

// Initial earnings data - realistic 30-day ranges
const initialEarningsRow1 = [
  { name: 'stephaniequinn', base: 202341.67 },  // Top earner
  { name: 'mileyreyes', base: 89156.89 },       // 60-120k range
  { name: 'piperraye', base: 42318.45 },        // 30-60k range
  { name: 'blairjoness', base: 67672.67 },      // 60-120k range
  { name: 'kamryngrace', base: 53892.34 },      // 30-60k range
  { name: 'hazelwilliamsss', base: 15234.78 },  // 10-20k range
];

const initialEarningsRow2 = [
  { name: 'brynleewest', base: 38421.56 },      // 30-60k range
  { name: 'ambererickson', base: 12847.23 },    // 10-20k range
  { name: 'corareed', base: 105234.89 },        // 60-120k range
  { name: 'quinnparker', base: 58421.23 },      // 30-60k range
  { name: 'dakotahayes', base: 18956.78 },      // 10-20k range
  { name: 'mandysweet2020', base: 47234.45 },   // 30-60k range
];

export default function Home() {
  const [scrolled, setScrolled] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [earningsRow1, setEarningsRow1] = useState(initialEarningsRow1.map(e => e.base));
  const [earningsRow2, setEarningsRow2] = useState(initialEarningsRow2.map(e => e.base));
  const heroRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
        const y = (e.clientY - rect.top - rect.height / 2) / rect.height;
        setMousePos({ x, y });
      }
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Live earnings counter effect
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly pick which row and which item to increment
      const row = Math.random() > 0.5 ? 1 : 2;
      const idx = Math.floor(Math.random() * 6);
      const increment = 7 + Math.random() * 14; // $7-21 increment
      
      if (row === 1) {
        setEarningsRow1(prev => {
          const newArr = [...prev];
          newArr[idx] = prev[idx] + increment;
          return newArr;
        });
      } else {
        setEarningsRow2(prev => {
          const newArr = [...prev];
          newArr[idx] = prev[idx] + increment;
          return newArr;
        });
      }
    }, 800 + Math.random() * 1200); // Every 0.8-2 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <main className="min-h-screen bg-plush-dark">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-plush-dark/90 backdrop-blur-lg border-b border-plush-border' : ''
      }`}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold tracking-wider text-plush-text">
            PLUSH
          </div>
          <div className="flex items-center gap-6">
            <a href="#journey" className="text-plush-text-muted hover:text-plush-text transition-colors text-sm">
              How It Works
            </a>
            <a href="#benefits" className="text-plush-text-muted hover:text-plush-text transition-colors text-sm">
              Benefits
            </a>
            <a 
              href="/onboarding" 
              className="btn-glow px-6 py-2.5 rounded-full text-white font-semibold text-sm"
            >
              Apply Now →
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background glow effects - with parallax */}
        <div className="absolute inset-0 bg-glow-pink opacity-50" />
        <div 
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-plush-pink/10 rounded-full blur-[100px] transition-transform duration-300"
          style={{ transform: `translate(${mousePos.x * 30}px, ${mousePos.y * 30}px)` }}
        />
        <div 
          className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-plush-pink/5 rounded-full blur-[80px] transition-transform duration-300"
          style={{ transform: `translate(${mousePos.x * -20}px, ${mousePos.y * -20}px)` }}
        />
        <div 
          className="absolute top-1/3 right-1/3 w-64 h-64 bg-plush-pink/5 rounded-full blur-[60px] transition-transform duration-300"
          style={{ transform: `translate(${mousePos.x * 40}px, ${mousePos.y * -40}px)` }}
        />
        
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-plush-card border border-plush-border mb-8 animate-fade-in">
            <span className="w-2 h-2 bg-plush-pink rounded-full animate-pulse" />
            <span className="text-sm text-plush-text-muted">Trusted by 120+ creators worldwide</span>
          </div>
          
          {/* Main headline */}
          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-slide-up">
            <span className="text-plush-text">Turn Your Content Into</span>
            <br />
            <span className="text-gradient">A 6-Figure Career</span>
          </h1>
          
          <p className="text-xl text-plush-text-muted max-w-2xl mx-auto mb-10 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Professional management for creators who want to stay anonymous, 
            build passive income, and live the lifestyle they deserve.
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <a 
              href="/onboarding" 
              className="btn-glow px-10 py-4 rounded-full text-white font-bold text-lg"
            >
              Start Your Journey →
            </a>
            <a 
              href="#journey" 
              className="px-10 py-4 rounded-full text-plush-text font-semibold text-lg border border-plush-border hover:border-plush-pink/50 transition-colors"
            >
              Learn More
            </a>
          </div>
          
          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-12 mt-16 animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <div className="text-center">
              <div className="text-4xl font-bold text-plush-pink stat-number">$20M+</div>
              <div className="text-sm text-plush-text-muted mt-1">Paid to Creators</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-plush-pink stat-number">120+</div>
              <div className="text-sm text-plush-text-muted mt-1">Active Models</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-plush-pink stat-number">24/7</div>
              <div className="text-sm text-plush-text-muted mt-1">Account Management</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-plush-pink stat-number">100%</div>
              <div className="text-sm text-plush-text-muted mt-1">Anonymous</div>
            </div>
          </div>
        </div>
        
        </section>

      {/* Live Earnings Feed - OF Widget Style - MOVED UP */}
      <section className="py-12 px-6">
        <div className="max-w-6xl mx-auto rounded-2xl overflow-hidden border-2 border-[#00AFF0] shadow-[0_0_40px_rgba(0,175,240,0.3)] bg-white">
        <div className="text-center py-8 px-6">
          <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-full bg-[#00AFF0] mb-4">
            <svg className="w-5 h-5" viewBox="0 0 400 400">
              <path fill="#fff" d="M137.5 75a125 125 0 10125 125 125 125 0 00-125-125zm0 162.5A37.5 37.5 0 11175 200a37.45 37.45 0 01-37.5 37.5z"/>
              <path fill="#fff" opacity="0.8" d="M278 168.75c31.76 9.14 69.25 0 69.25 0-10.88 47.5-45.38 77.25-95.13 80.87A124.73 124.73 0 01137.5 325L175 205.81C213.55 83.3 233.31 75 324.73 75h62.77c-10.5 46.25-46.69 81.58-109.5 93.75z"/>
            </svg>
            <span className="text-white font-semibold text-sm">Powered by OnlyFans</span>
            <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
            Real-Time <span className="text-[#00AFF0]">Earnings</span>
          </h2>
          <p className="text-gray-500">Last 30 day earnings synced live</p>
        </div>
        
        <div className="relative bg-white py-6 pb-10">
          <div className="marquee-container mb-4">
            <div className="marquee-content">
              {[...Array(2)].map((_, setIndex) => (
                <div key={setIndex} className="flex gap-4">
                  {initialEarningsRow1.map((item, i) => (
                    <div key={`${setIndex}-${i}`} className="flex-shrink-0 flex items-center gap-3 px-4 py-3 rounded-xl bg-white border border-gray-200 shadow-sm">
                      <div className="w-10 h-10 rounded-full bg-[#00AFF0] flex items-center justify-center">
                        <svg className="w-6 h-6" viewBox="0 0 400 400">
                          <path fill="#fff" d="M137.5 75a125 125 0 10125 125 125 125 0 00-125-125zm0 162.5A37.5 37.5 0 11175 200a37.45 37.45 0 01-37.5 37.5z"/>
                          <path fill="#fff" opacity="0.8" d="M278 168.75c31.76 9.14 69.25 0 69.25 0-10.88 47.5-45.38 77.25-95.13 80.87A124.73 124.73 0 01137.5 325L175 205.81C213.55 83.3 233.31 75 324.73 75h62.77c-10.5 46.25-46.69 81.58-109.5 93.75z"/>
                        </svg>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xl font-bold text-gray-900">${earningsRow1[i].toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                          <span className="text-[10px] px-1.5 py-0.5 bg-green-100 text-green-600 rounded font-medium animate-pulse">LIVE</span>
                        </div>
                        <div className="text-xs text-gray-500">{anonymize(item.name)} • 30 days</div>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
          
          <div className="marquee-container-reverse">
            <div className="marquee-content-reverse">
              {[...Array(2)].map((_, setIndex) => (
                <div key={setIndex} className="flex gap-4">
                  {initialEarningsRow2.map((item, i) => (
                    <div key={`${setIndex}-${i}`} className="flex-shrink-0 flex items-center gap-3 px-4 py-3 rounded-xl bg-white border border-gray-200 shadow-sm">
                      <div className="w-10 h-10 rounded-full bg-[#00AFF0] flex items-center justify-center">
                        <svg className="w-6 h-6" viewBox="0 0 400 400">
                          <path fill="#fff" d="M137.5 75a125 125 0 10125 125 125 125 0 00-125-125zm0 162.5A37.5 37.5 0 11175 200a37.45 37.45 0 01-37.5 37.5z"/>
                          <path fill="#fff" opacity="0.8" d="M278 168.75c31.76 9.14 69.25 0 69.25 0-10.88 47.5-45.38 77.25-95.13 80.87A124.73 124.73 0 01137.5 325L175 205.81C213.55 83.3 233.31 75 324.73 75h62.77c-10.5 46.25-46.69 81.58-109.5 93.75z"/>
                        </svg>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xl font-bold text-gray-900">${earningsRow2[i].toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                          <span className="text-[10px] px-1.5 py-0.5 bg-green-100 text-green-600 rounded font-medium animate-pulse">LIVE</span>
                        </div>
                        <div className="text-xs text-gray-500">{anonymize(item.name)} • 30 days</div>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
          
          <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-white to-transparent pointer-events-none z-10" />
          <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-white to-transparent pointer-events-none z-10" />
          <div className="absolute bottom-2 right-4 flex items-center gap-2 text-xs text-[#00AFF0]">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
            <span>Syncing live data...</span>
          </div>
        </div>
        </div>
      </section>

      {/* What Models Want Section */}
      <section id="benefits" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-plush-text mb-4">
              What <span className="text-gradient">You Get</span>
            </h2>
            <p className="text-xl text-plush-text-muted max-w-2xl mx-auto">
              Everything you need to build a successful creator business — without anyone knowing
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Card 1 */}
            <div className="card-premium rounded-2xl p-8">
              <div className="w-14 h-14 bg-plush-pink/10 rounded-xl flex items-center justify-center mb-6">
                <span className="text-3xl">🔒</span>
              </div>
              <h3 className="text-xl font-bold text-plush-text mb-3">Complete Anonymity</h3>
              <p className="text-plush-text-muted">
                Your identity stays hidden. We handle everything so no one ever has to know.
              </p>
            </div>
            
            {/* Card 2 */}
            <div className="card-premium rounded-2xl p-8">
              <div className="w-14 h-14 bg-plush-pink/10 rounded-xl flex items-center justify-center mb-6">
                <span className="text-3xl">💰</span>
              </div>
              <h3 className="text-xl font-bold text-plush-text mb-3">Passive Income</h3>
              <p className="text-plush-text-muted">
                Our team works around the clock. You create content, we handle the rest.
              </p>
            </div>
            
            {/* Card 3 */}
            <div className="card-premium rounded-2xl p-8">
              <div className="w-14 h-14 bg-plush-pink/10 rounded-xl flex items-center justify-center mb-6">
                <span className="text-3xl">✨</span>
              </div>
              <h3 className="text-xl font-bold text-plush-text mb-3">Luxury Lifestyle</h3>
              <p className="text-plush-text-muted">
                Travel. Freedom. No 9-5. Build the life you've always dreamed of.
              </p>
            </div>
            
            {/* Card 4 */}
            <div className="card-premium rounded-2xl p-8">
              <div className="w-14 h-14 bg-plush-pink/10 rounded-xl flex items-center justify-center mb-6">
                <span className="text-3xl">👯‍♀️</span>
              </div>
              <h3 className="text-xl font-bold text-plush-text mb-3">Community & Content Trips</h3>
              <p className="text-plush-text-muted">
                Join a network of successful creators. Exclusive content trips to exotic locations with your new friends.
              </p>
            </div>
            
            {/* Card 5 */}
            <div className="card-premium rounded-2xl p-8">
              <div className="w-14 h-14 bg-plush-pink/10 rounded-xl flex items-center justify-center mb-6">
                <span className="text-3xl">📈</span>
              </div>
              <h3 className="text-xl font-bold text-plush-text mb-3">Growth Strategy</h3>
              <p className="text-plush-text-muted">
                Custom marketing, cross-promotion, and growth tactics to scale your income.
              </p>
            </div>
            
            {/* Card 6 */}
            <div className="card-premium rounded-2xl p-8">
              <div className="w-14 h-14 bg-plush-pink/10 rounded-xl flex items-center justify-center mb-6">
                <span className="text-3xl">🎯</span>
              </div>
              <h3 className="text-xl font-bold text-plush-text mb-3">Dedicated Team</h3>
              <p className="text-plush-text-muted">
                Your own manager, chat team, and support crew working for your success.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Journey Section */}
      <section id="journey" className="py-24 px-6 bg-plush-darker">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-plush-text mb-4">
              Your <span className="text-gradient">Onboarding Journey</span>
            </h2>
            <p className="text-xl text-plush-text-muted max-w-2xl mx-auto">
              From application to earning — here's how it works
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { num: '01', title: 'Apply', desc: 'Fill out our quick application form' },
              { num: '02', title: 'Sign Agreement', desc: 'Review and sign your contract' },
              { num: '03', title: 'Upload Content', desc: 'Submit your initial content bundle' },
              { num: '04', title: 'Go Live', desc: 'We launch your account and start earning' },
              { num: '05', title: 'Get Managed', desc: 'Our team handles fans, DMs, and sales' },
              { num: '06', title: 'Create & Stream', desc: 'Focus on content while we do the rest' },
              { num: '07', title: 'Watch It Grow', desc: 'Track earnings in your dashboard' },
              { num: '08', title: 'Get Paid', desc: 'Weekly payouts to your account' },
            ].map((step, i) => (
              <div key={i} className="card-premium rounded-2xl p-6 relative group">
                <div className="text-6xl font-bold text-plush-pink/10 absolute top-4 right-4 group-hover:text-plush-pink/20 transition-colors">
                  {step.num}
                </div>
                <div className="relative z-10">
                  <div className="text-sm font-bold text-plush-pink mb-2">STEP {step.num}</div>
                  <h3 className="text-lg font-bold text-plush-text mb-2">{step.title}</h3>
                  <p className="text-sm text-plush-text-muted">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Earnings Section */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-plush-text mb-4">
            Ready to <span className="text-gradient">Start Earning?</span>
          </h2>
          <p className="text-xl text-plush-text-muted mb-10 max-w-2xl mx-auto">
            Our creators earn $10K-$200K per month. The only question is — are you ready?
          </p>
          
          <div className="card-premium rounded-3xl p-10 mb-10">
            <div className="text-5xl md:text-7xl font-bold text-gradient mb-4">
              $100,000 - $1M+
            </div>
            <div className="text-xl text-plush-text-muted">
              Annual earnings for active creators
            </div>
          </div>
          
          <a 
            href="/onboarding" 
            className="btn-glow inline-flex items-center gap-3 px-12 py-5 rounded-full text-white font-bold text-xl"
          >
            Apply Now — It's Free
            <span>→</span>
          </a>
          
          <p className="text-sm text-plush-text-muted mt-6">
            No upfront costs. We only earn when you earn.
          </p>
        </div>
      </section>

      {/* Powered by Daisio */}
      <section className="py-12 px-6 border-t border-plush-border bg-plush-darker">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-plush-card border border-plush-border mb-4">
            <span className="text-sm text-plush-text-muted">Powered by</span>
            <span className="text-lg font-bold text-gradient">Daisio</span>
            <span className="text-xs px-2 py-0.5 bg-plush-pink/20 text-plush-pink rounded-full">Split Pay</span>
          </div>
          <p className="text-plush-text-muted text-sm max-w-xl mx-auto">
            Receive payments every 2 weeks through our third-party partnership with Daisio — secure, transparent, and automatic.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-plush-border">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-xl font-bold tracking-wider">PLUSH</div>
          <div className="flex items-center gap-6 text-sm text-plush-text-muted">
            <a href="#" className="hover:text-plush-text transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-plush-text transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-plush-text transition-colors">Contact</a>
          </div>
          <div className="text-sm text-plush-text-muted">
            © 2016-2025 Plush. All Rights Reserved.
          </div>
        </div>
      </footer>
    </main>
  );
}

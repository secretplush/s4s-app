import type { Config } from "tailwindcss";

export default {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        plush: {
          pink: '#FF3B7F',
          'pink-glow': '#FF6B9D',
          'pink-soft': '#FFB3CB',
          'pink-dark': '#CC2F66',
          hot: '#FF1B6B',
          dark: '#0A0A0B',
          darker: '#050506',
          card: '#111113',
          'card-hover': '#1A1A1D',
          border: '#2A2A2E',
          text: '#FAFAFA',
          'text-muted': '#888888',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Inter', 'system-ui', 'sans-serif'],
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'glow-pink': 'radial-gradient(circle at center, rgba(255,59,127,0.15) 0%, transparent 70%)',
        'hero-gradient': 'linear-gradient(180deg, #0A0A0B 0%, #0F0F11 50%, #0A0A0B 100%)',
      },
      boxShadow: {
        'glow': '0 0 60px rgba(255,59,127,0.3)',
        'glow-sm': '0 0 30px rgba(255,59,127,0.2)',
        'card': '0 4px 20px rgba(0,0,0,0.4)',
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'fade-in': 'fade-in 0.5s ease-out',
        'slide-up': 'slide-up 0.5s ease-out',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 20px rgba(255,59,127,0.3)' },
          '50%': { boxShadow: '0 0 40px rgba(255,59,127,0.5)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'slide-up': {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
} satisfies Config;
